# Custom Setup Samples

With `plutonium-backend-addon-custom-setup.mjs` installed, copy these files into your Foundry data folder (alongside the `modules`, `systems`, and `worlds` directories).
