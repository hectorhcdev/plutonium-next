export class Const {
	static STATES = ["0", "1", "2"]; // off, blue, red
	static GH_PATH = `https://raw.githubusercontent.com/5etools-mirror-1/pab-index/main/`;
	static FAKE_FILTER_ARTIST = "Artist";
	static FAKE_FILTER_SET = "Collection";
	static IMG_LAZY_180 = `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180"><rect width="100%" height="100%" fill="#8883"></rect></svg>`)}`;
}
